import org.junit.Test;
import static org.junit.Assert.*;

public class MainTest {
  // @Test
  // public void ReturnCorrectReport() {
  //   assertEquals("ALICE99 4 240\nCHARLIE 3 37", Main.outputReport(""));
  // }
}
