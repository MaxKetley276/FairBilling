import java.time.LocalTime;

public class Session {
  public String userName;
  public LocalTime start;
  public String state;  // Active, Inactive
  public Integer durationSeconds;
}