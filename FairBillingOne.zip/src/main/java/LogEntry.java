import java.time.LocalTime;

public class LogEntry {
  public String userName;
  public LocalTime start;
  public String action;
}